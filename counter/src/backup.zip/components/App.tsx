import { FC } from 'react'
import { Provider } from "react-redux"
import SearchRepositoriesList from "./SearchRepositoriesList"
import { store } from "../redux"

const App: FC = () => {
  return (
    <Provider store={store}>
      <h1>Search NPM for Repositories</h1>
      <SearchRepositoriesList />
    </Provider>
  );
}

export default App;