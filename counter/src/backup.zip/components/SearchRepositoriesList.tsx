import { FC } from 'react';
import { useState } from 'react';
import { useActions } from '../hooks/useActions';
import { useAppSelector } from '../hooks/useTypedSelector';

const SearchRepositoriesList: FC = () => {
  const [term, setTerm] = useState('');
  const { data, loading, error } = useAppSelector((state) => state.repositories); // type을 붙인 custom useSelector를 사용한다.
  const { searchRepositories } = useActions();
  const onSubmit: React.FormEventHandler<HTMLFormElement> = (e) => {
    e.preventDefault();

    searchRepositories(term); // submit시에 특정 action을 dispatch한다.
  }

  return (
    <div>
      <form onSubmit={onSubmit}>
        <input value={term} onChange={(e) => setTerm(e.target.value)} />
        <button>Search</button>
      </form>
      <ul>{!loading && data.map((name) => <li key={name}>{name}</li>)}</ul>
      {error && <h3>{error}</h3>} // error 테스트는 개발자도구 Network 탭에서 offline으로 설정하여 테스트한다.
    </div>
  );
}

export default SearchRepositoriesList;